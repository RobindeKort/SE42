Ik heb gebruik gemaakt van een locale database

Databasename: software
Username: root
Password: ""
